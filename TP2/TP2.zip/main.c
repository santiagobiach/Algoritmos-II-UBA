#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "menu.h"

int main(){

	juego_t* juego = crear_juego();
	menu_de_inicio(juego);
	eliminar_juego(juego);
	return 0;
}