#ifndef __ADMINISTRATIVAS_H__
#define __ADMINISTRATIVAS_H__

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* leer_linea(char* memoria, int tamanio, FILE* archivo);


#endif /* __ADMINISTRATIVAS_H__*/